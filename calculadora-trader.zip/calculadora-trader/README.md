# Calculadora trader

A Pen created on CodePen.

Original URL: [https://codepen.io/Pablete77/pen/myEqEEV](https://codepen.io/Pablete77/pen/myEqEEV).

